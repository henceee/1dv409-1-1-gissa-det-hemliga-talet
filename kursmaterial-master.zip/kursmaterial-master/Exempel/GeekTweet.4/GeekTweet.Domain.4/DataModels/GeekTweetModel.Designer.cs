﻿// Default code generation is disabled for model 'C:\My Dropbox\Kurser\1dv409\github-1dv409\kursmaterial\Exempel\GeekTweet.4\GeekTweet.Domain.4\DataModels\GeekTweetModel.edmx'. 
// To enable default code generation, change the value of the 'Code Generation Strategy' designer
// property to an alternate value. This property is available in the Properties Window when the model is
// open in the designer.